﻿using Banking.Domain.Abstract_Classes;
using Banking.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Classes
{
    // BankEmployee implements IBankEmployee to manage customer accounts and transactions.
    public class BankEmployee : IBankEmployee
    {
        private List<Customer> customers;

        public BankEmployee()
        {
            customers = new List<Customer>();
        }

        // Function to create a new customer and add them to the customer list.
        public void CreateCustomer(string firstName, string lastName, string email)
        {
            try
            {
                string accountNumber = GenerateAccountNumber(firstName, lastName);
                string pin = GeneratePin(firstName, lastName);
                var customer = new Customer(firstName, lastName, accountNumber, pin);
                customers.Add(customer);
                Console.WriteLine("\nCustomer created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while creating the customer: {ex.Message}");
            }
        }

        // Function to delete a customer if their accounts have zero balance.
        public void DeleteCustomer(string accountNumber)
        {
            try
            {
                var customer = customers.FirstOrDefault(c => c.AccountNumber == accountNumber);
                if (customer != null)
                {
                    if (customer.SavingsAccount != null && customer.CurrentAccount != null &&
                        customer.SavingsAccount.Balance == 0 && customer.CurrentAccount.Balance == 0)
                    {
                        customers.RemoveAll(c => c.AccountNumber == accountNumber);
                        Console.WriteLine("\nCustomer deleted.");
                    }
                    else
                    {
                        Console.WriteLine("\nCustomer has non-zero balances, cannot delete.");
                    }
                }
                else
                {
                    Console.WriteLine("\nCustomer not found.");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while deleting the customer: {ex.Message}");
            }
        }

        // Function to list all customers with their account balance details.
        public List<string> ListCustomers()
        {
            List<string> list = new List<string>();

            try
            {
                foreach (var customer in customers)
                {
                    var customerDetail = $"\n{customer.FirstName} {customer.LastName} ({customer.AccountNumber}) - Savings: {customer.SavingsAccount.Balance}, Current: {customer.CurrentAccount.Balance}";
                    Console.WriteLine(customerDetail);
                    list.Add(customerDetail);
                }

                var fileManager = new FileManager();
                fileManager.AddDataInCustomerFile(list);

                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while listing customers: {ex.Message}");
                return null;
            }


        }

        // Function to retrieve a customer by account number and pin for login.
        public Customer GetCustomer(string accountNumber, string pin)
        {
            try
            {
                var customer =  customers.FirstOrDefault(c => c.AccountNumber == accountNumber && c.Pin == pin);
                return customer;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while retrieving the customer: {ex.Message}");
                return null; // Return null if an error occurs
            }
        }

        // Function to create a deposit or withdrawal transaction for a specified account.
        public void CreateTransaction(string accountNumber, string accountType, double amount, string transactionType)
        {
            try
            {
                var customer = customers.FirstOrDefault(c => c.AccountNumber == accountNumber);
                if (customer != null)
                {
                    if (accountType.ToLower() == "savings")
                    {
                        if (transactionType.ToLower() == "deposit")
                            customer.SavingsAccount.Deposit(amount);

                        else if (transactionType.ToLower() == "withdraw")
                            customer.SavingsAccount.Withdraw(amount);
                    }
                    else if (accountType.ToLower() == "current")
                    {
                        if (transactionType.ToLower() == "deposit")
                            customer.CurrentAccount.Deposit(amount);
                        else if (transactionType.ToLower() == "withdraw")
                            customer.CurrentAccount.Withdraw(amount);
                    }
                    else
                    {
                        Console.WriteLine("\nInvalid account type.");
                    }
                }
                else
                {
                    Console.WriteLine("\nCustomer not found.");
                }

                var fileManager = new FileManager();
                fileManager.SaveTransactions(accountNumber, accountType, transactionType + " " + amount);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while processing the transaction: {ex.Message}");
            }
        }

        // Function to generate an account number based on the customer's name.
        private string GenerateAccountNumber(string firstName, string lastName)
        {
            try
            {
                string initials = firstName.Substring(0, 1).ToLower() + lastName.Substring(0, 1).ToLower();
                int nameLength = firstName.Length + lastName.Length;
                int firstInitialPos = Char.ToUpper(firstName[0]) - 'A' + 1;
                int secondInitialPos = Char.ToUpper(lastName[0]) - 'A' + 1;
                return $"{initials}-{nameLength}-{firstInitialPos}-{secondInitialPos}";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while generating the account number: {ex.Message}");
                return string.Empty;
            }
        }

        // Function to generate a pin based on the first letters of the customer's first and last names.
        private string GeneratePin(string firstName, string lastName)
        {
            try
            {
                int firstInitialPos = Char.ToUpper(firstName[0]) - 'A' + 1;
                int secondInitialPos = Char.ToUpper(lastName[0]) - 'A' + 1;
                return $"{firstInitialPos}{secondInitialPos}";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nAn error occurred while generating the PIN: {ex.Message}");
                return string.Empty;
            }
        }
    }
}
