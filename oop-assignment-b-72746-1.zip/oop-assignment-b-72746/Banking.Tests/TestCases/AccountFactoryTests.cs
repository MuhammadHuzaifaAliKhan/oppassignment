﻿using Xunit;
using Banking.Domain.Classes;

namespace Banking.Tests.TestCases
{
    public class AccountFactoryTests
    {
        [Fact]
        public void CreateSavingsAccount_CreatesNewSavingsAccountInstance()
        {
            // Arrange
            var accountFactory = new AccountFactory();

            // Act
            var savingsAccount = accountFactory.CreateSavingsAccount();

            // Assert
            Assert.NotNull(savingsAccount);  // Ensure that the savings account is not null
            Assert.IsType<SavingsAccount>(savingsAccount);  // Ensure that the created account is of type SavingsAccount
            Assert.Equal(0, savingsAccount.Balance);  // Check if the default balance is set to 0
        }

        [Fact]
        public void CreateCurrentAccount_CreatesNewCurrentAccountInstance()
        {
            // Arrange
            var accountFactory = new AccountFactory();

            // Act
            var currentAccount = accountFactory.CreateCurrentAccount();

            // Assert
            Assert.NotNull(currentAccount);  // Ensure that the current account is not null
            Assert.IsType<CurrentAccount>(currentAccount);  // Ensure that the created account is of type CurrentAccount
            Assert.Equal(0, currentAccount.Balance);  // Check if the default balance is set to 0
        }

        [Fact]
        public void CreateSavingsAccount_ReturnsDifferentInstances()
        {
            // Arrange
            var accountFactory = new AccountFactory();

            // Act
            var savingsAccount1 = accountFactory.CreateSavingsAccount();
            var savingsAccount2 = accountFactory.CreateSavingsAccount();

            // Assert
            Assert.NotSame(savingsAccount1, savingsAccount2);  // Ensure that two created accounts are different instances
        }

        [Fact]
        public void CreateCurrentAccount_ReturnsDifferentInstances()
        {
            // Arrange
            var accountFactory = new AccountFactory();

            // Act
            var currentAccount1 = accountFactory.CreateCurrentAccount();
            var currentAccount2 = accountFactory.CreateCurrentAccount();

            // Assert
            Assert.NotSame(currentAccount1, currentAccount2);  // Ensure that two created accounts are different instances
        }
    }
}
