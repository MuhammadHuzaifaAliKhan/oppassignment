﻿using Xunit;
using Banking.Domain.Classes;

namespace Banking.Tests.TestCases
{
    public class CustomerTests
    {
        private Customer _customer;

        public CustomerTests()
        {
            _customer = new Customer("John", "Doe", "jd-8-10-15", "1015");
        }

        [Fact]
        public void DepositMoney_ValidAmount_AmountDeposited()
        {
            _customer.SavingsAccount.ResetBalance();

            // Arrange
            double depositAmount = 1000;

            // Act
            _customer.SavingsAccount.Deposit(depositAmount);

            // Assert
            Assert.Equal(1000, _customer.SavingsAccount.Balance);
        }

        [Fact]
        public void WithdrawMoney_ValidAmount_AmountWithdrawn()
        {
            _customer.SavingsAccount.ResetBalance();

            // Arrange
            double depositAmount = 1000;
            _customer.SavingsAccount.Deposit(depositAmount);

            // Act
            _customer.SavingsAccount.Withdraw(500);

            // Assert
            Assert.Equal(500, _customer.SavingsAccount.Balance);
        }

        [Fact]
        public void WithdrawMoney_InsufficientFunds_ThrowsException()
        {
            _customer.SavingsAccount.ResetBalance();

            // Arrange
            double initialBalance = 100;
            _customer.SavingsAccount.Deposit(initialBalance);

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() => _customer.SavingsAccount.Withdraw(200));
            Assert.Equal("Insufficient funds.", exception.Message);
        }

        [Fact]
        public void ViewAccountDetails_ReturnsCorrectDetails()
        {
            _customer.SavingsAccount.ResetBalance();

            // Arrange
            _customer.SavingsAccount.Deposit(500);
            _customer.CurrentAccount.Deposit(300);

            // Act
            var accountDetails = _customer.GetAccountDetails();

            // Assert
            Assert.Equal("Savings: 500, Current: 300", accountDetails);
        }
    }
}
