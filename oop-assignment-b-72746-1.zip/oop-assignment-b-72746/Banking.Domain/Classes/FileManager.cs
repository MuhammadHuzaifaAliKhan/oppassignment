﻿using Banking.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Classes
{
    // FileManager implements IFileManager for handling file operations
    public class FileManager : IFileManager
    {
        //Function to creates a customer file if it does not already exist
        public void CreateCustomerFile(string filename)
        {
            if (!File.Exists(filename))
            {
                using (var fs = File.Create(filename))
                {
                    Console.WriteLine($"{filename} created.");
                }
            }
        }

        public void AddDataInCustomerFile(List<string> customerDetails)
        {
            string fileName = "customers.txt";
            CreateCustomerFile(fileName);
            foreach( var customer in customerDetails)
            {
                File.AppendAllText(fileName, customer + Environment.NewLine);

            }
        }

        //Function to saves transaction details to a file based on account number and type
        public void SaveTransactions(string accountNumber, string accountType, string transactionDetails)
        {
            string fileName = $"{accountNumber}-{accountType}.txt";
            File.AppendAllText(fileName, transactionDetails + Environment.NewLine);
        }
    }
}
