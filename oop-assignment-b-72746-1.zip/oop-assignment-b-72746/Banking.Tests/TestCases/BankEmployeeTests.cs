﻿using Xunit;
using Banking.Domain.Classes;
using System.Linq;

namespace Banking.Tests.TestCases
{
    public class BankEmployeeTests
    {
        private BankEmployee _bankEmployee;

        public BankEmployeeTests()
        {
            _bankEmployee = new BankEmployee();
        }

        [Fact]
        public void CreateCustomer_ValidData_CustomerCreated()
        {
            // Arrange
            string firstName = "John";
            string lastName = "Doe";
            string email = "john.doe@example.com";

            // Act
            _bankEmployee.CreateCustomer(firstName, lastName, email);

            // Assert
            var customer = _bankEmployee.GetCustomer("jd-7-10-4", "104");
            Assert.NotNull(customer);
            Assert.Equal("John", customer.FirstName);
            Assert.Equal("Doe", customer.LastName);
        }

        [Fact]
        public void DeleteCustomer_CustomerExists_DeletedSuccessfully()
        {
            // Arrange
            string firstName = "John";
            string lastName = "Doe";
            _bankEmployee.CreateCustomer(firstName, lastName, "john.doe@example.com");
            var customer = _bankEmployee.GetCustomer("jd-7-10-4", "104");

            // Act
            _bankEmployee.DeleteCustomer(customer.AccountNumber);

            // Assert
            var deletedCustomer = _bankEmployee.GetCustomer("jd-7-10-4", "104");
            Assert.Null(deletedCustomer);
        }

        [Fact]
        public void ListCustomers_CustomersExist_ListsCustomers()
        {
            // Arrange
            _bankEmployee.CreateCustomer("John", "Doe", "john.doe@example.com");
            _bankEmployee.CreateCustomer("Jane", "Doe", "jane.doe@example.com");

            // Act
            var customers = _bankEmployee.ListCustomers();

            // Assert
            Assert.Equal(2, customers.Count());
        }

        [Fact]
        public void CreateTransaction_ValidTransaction_TransactionCreated()
        {
            // Arrange
            _bankEmployee.CreateCustomer("John", "Doe", "john.doe@example.com");
            var customer = _bankEmployee.GetCustomer("jd-7-10-4", "104");

            // Act
            _bankEmployee.CreateTransaction(customer.AccountNumber, "savings", 500, "deposit");

            // Assert
            Assert.Equal(500, customer.SavingsAccount.Balance);
        }
    }
}
