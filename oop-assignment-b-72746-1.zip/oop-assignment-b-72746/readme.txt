# Banking System Project

## Overview
This project is a **Banking System** that allows customers and bank employees to interact with the system through a console interface. It includes functionality such as account management, transaction processing, and user authentication. The system has been designed with multiple roles, namely Bank Employee and Customer.

## Features Implemented

### 1. **Bank Employee Functionality**
- **Login System**: Bank employees can log in using a specific PIN (`A1234`).
- **Menu Options**: Employees have access to a menu with the following options:
  - Create a new customer.
  - Delete an existing customer.
  - List all customers.
  - Create transactions (Deposit/Withdraw).
  
### 2. **Customer Functionality**
- **Login**: Customers can log in by entering their name, account number, and pin number.
- **Account Operations**:
  - Customers can deposit and withdraw money from their **Savings** and **Current** accounts.
  - Transaction history is available to view for both Savings and Current accounts.
  - Negative balances are not allowed.
  
### 3. **Abstract Class and Inheritance**
- **Abstract Account Class**: An abstract class `Account` was created to define common behavior for account classes.
- **Savings and Current Accounts**: Both `SavingsAccount` and `CurrentAccount` are concrete implementations of the `Account`, providing specific behaviors for deposit and withdrawal.
  
### 4. **Menu System**
- **Employee Menu**: A menu was created for bank employees with the options to manage customers and transactions.
- **Customer Menu**: A separate menu system for customer-related operations (login, transactions).
  
### 5. **Error Handling**
- **Exception Handling**: Error handling has been implemented for user inputs and other unexpected errors using `try-catch` blocks to ensure the program runs smoothly even in case of invalid input or errors.

### 6. **Program Flow**
- **Switch Statements**: Switch-case logic was used in the program's main flow for the user to select whether they are a customer or a bank employee.
- **Customer and Employee Login**: Based on the user type, the correct menu is shown, and operations are executed accordingly.

## Challenges and Issues

### What was completed:
- All major features outlined in the requirements were implemented, including:
  - **Bank Employee and Customer menus**
  - **Account operations (Deposit, Withdraw)**
  - **Transaction history display**
  - **Login system for both employee and customer**
  - **Abstract Account Class and inheritance for specific account types**

### What couldn't be completed:
- **Unit Testing**: Although the project structure is in place for unit testing, time constraints prevented the implementation of comprehensive unit tests for each method and class.
- **Data Persistence**: While the system can handle transactions and accounts, there is no long-term data persistence (e.g., saving account details to a database or file).
- **Multi-user or Concurrent Operations**: The application is single-user and doesn't handle concurrent access or multi-user support.
- **GUI Integration**: The system is designed as a console application, and integrating a GUI (Graphical User Interface) was not attempted.

### Future Work:
- **Unit Testing**: Implement unit tests for critical components like `Account`, `BankEmployee`, and transaction handling.
- **Database Integration**: Add functionality to persist user data and transaction history in a database.
- **Multi-user Support**: Extend the program to support multiple users simultaneously (e.g., using threads or a client-server architecture).
- **GUI**: Build a graphical user interface for better usability.

## Conclusion
This Banking System project demonstrates basic banking operations with role-based functionality (Bank Employee and Customer). It also introduces key concepts such as inheritance, exception handling, and menu-based user interaction. While some features like unit tests and multi-user support were not implemented, the core functionalities have been completed successfully.

## Running the Application
To run the application:
1. Compile the solution in Visual Studio or any other C# IDE.
2. Run the `Program.cs` file.
3. Follow the on-screen prompts to interact with the system.

## Tools and Technologies
- **C#**: Primary programming language used.
- **.NET Core**: Framework for building the console application.
- **Console Application**: The user interface is text-based using `Console.WriteLine()` and `Console.ReadLine()` for interaction.

## Credits
- Developed by: Muhammad Huzaifa Khan
- Mentor: 72746
