﻿using Xunit;
using Banking.Domain.Classes;
using System;
using System.IO;

namespace Banking.Tests.TestCases
{
    public class FileManagerTests
    {
        private readonly string testFileName = "testCustomerFile.txt";

        // Clean up any test files after running the tests
        public FileManagerTests()
        {
            if (File.Exists(testFileName))
            {
                File.Delete(testFileName);
            }
        }

        [Fact]
        public void CreateCustomerFile_CreatesFileIfNotExist()
        {
            // Arrange
            var fileManager = new FileManager();

            // Act
            fileManager.CreateCustomerFile(testFileName);

            // Assert
            Assert.True(File.Exists(testFileName));  // Ensure that the file was created
        }

        [Fact]
        public void CreateCustomerFile_DoesNotOverwriteExistingFile()
        {
            // Arrange
            var fileManager = new FileManager();
            File.Create(testFileName).Dispose();  // Create the file before testing

            // Act
            fileManager.CreateCustomerFile(testFileName);

            // Assert
            Assert.True(File.Exists(testFileName));  // Ensure the file still exists
        }

        [Fact]
        public void SaveTransactions_AppendsTransactionDetailsToFile()
        {
            // Arrange
            var fileManager = new FileManager();
            string accountNumber = "123456";
            string accountType = "savings";
            string transactionDetails = "Deposit 1000";

            // Act
            fileManager.SaveTransactions(accountNumber, accountType, transactionDetails);

            // Assert
            string fileName = $"{accountNumber}-{accountType}.txt";
            Assert.True(File.Exists(fileName));  // Ensure that the file was created
            string fileContents = File.ReadAllText(fileName);
            Assert.Contains(transactionDetails, fileContents);  // Ensure that the transaction details are saved in the file
        }

        [Fact]
        public void SaveTransactions_CreatesNewFileIfNotExist()
        {
            // Arrange
            var fileManager = new FileManager();
            string accountNumber = "123456";
            string accountType = "current";
            string transactionDetails = "Withdraw 500";

            // Act
            fileManager.SaveTransactions(accountNumber, accountType, transactionDetails);

            // Assert
            string fileName = $"{accountNumber}-{accountType}.txt";
            Assert.True(File.Exists(fileName));  // Ensure that the file is created if it doesn't exist
        }

        [Fact]
        public void SaveTransactions_AppendsToExistingFile()
        {
            // Arrange
            var fileManager = new FileManager();
            string accountNumber = "123456";
            string accountType = "savings";
            string transactionDetails1 = "Deposit 1000";
            string transactionDetails2 = "Withdraw 500";

            // Act
            fileManager.SaveTransactions(accountNumber, accountType, transactionDetails1);
            fileManager.SaveTransactions(accountNumber, accountType, transactionDetails2);

            // Assert
            string fileName = $"{accountNumber}-{accountType}.txt";
            string fileContents = File.ReadAllText(fileName);
            Assert.Contains(transactionDetails1, fileContents);  // Ensure the first transaction is in the file
            Assert.Contains(transactionDetails2, fileContents);  // Ensure the second transaction is in the file
        }
    }
}
