﻿using Xunit;
using Banking.Domain.Classes;
using Banking.Domain.Interfaces;

namespace Banking.Tests.TestCases
{
    public class SavingsAccountTests
    {
        private SavingsAccount _savingsAccount;

        public SavingsAccountTests()
        {
            _savingsAccount = new SavingsAccount();
        }

        [Fact]
        public void Deposit_ValidAmount_IncreasesBalance()
        {
            _savingsAccount.ResetBalance();

            // Act
            _savingsAccount.Deposit(1000);

            // Assert
            Assert.Equal(1000, _savingsAccount.Balance);
        }

        [Fact]
        public void Withdraw_ValidAmount_DecreasesBalance()
        {
            _savingsAccount.ResetBalance();

            // Arrange
            _savingsAccount.Deposit(1000);

            // Act
            _savingsAccount.Withdraw(500);

            // Assert
            Assert.Equal(500, _savingsAccount.Balance);
        }

        [Fact]
        public void Withdraw_InsufficientFunds_ThrowsException()
        {
            _savingsAccount.ResetBalance();

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() => _savingsAccount.Withdraw(1000));
            Assert.Equal("Insufficient funds.", exception.Message);
        }
    }
}
