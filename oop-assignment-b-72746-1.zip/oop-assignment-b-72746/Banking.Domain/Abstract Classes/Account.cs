﻿using Banking.Domain.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Abstract_Classes
{
    // Abstract Account class representing general account behavior
    public abstract class Account
    {
        public double Balance { get; protected set; }
        public List<Transaction> Transactions { get; protected set; }

        // Constructor to initialize common properties
        protected Account()
        {
            Balance = 0.0;
            Transactions = new List<Transaction>();
        }

        // Abstract methods to be implemented by derived classes
        public abstract void Deposit(double amount);
        public abstract void Withdraw(double amount);

        // Method to retrieve transaction history
        public List<Transaction> GetTransactions()
        {
            return Transactions;
        }

        // Shared method to add a transaction
        protected void AddTransaction(string type, double amount)
        {
            var transaction = Transaction.CreateTransaction(type, amount, Balance);
            Transactions.Add(transaction);
        }
    }
}
