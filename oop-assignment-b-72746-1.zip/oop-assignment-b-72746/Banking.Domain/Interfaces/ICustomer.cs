﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Interfaces
{
    public interface ICustomer
    {
        //Functions Signature
        bool Login(string accountNumber, string pin);
        void ViewTransactionHistory(string accountType);
        void Deposit(string accountType, double amount);
        void Withdraw(string accountType, double amount);
        string GetAccountDetails();
    }
}
