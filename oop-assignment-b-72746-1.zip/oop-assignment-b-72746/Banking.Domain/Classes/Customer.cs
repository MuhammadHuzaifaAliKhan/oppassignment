﻿using Banking.Domain.Abstract_Classes;
using Banking.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Classes
{
    // Customer implements ICustomer to represents a customer with personal details and account functionality.
    public class Customer : ICustomer
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string AccountNumber { get; private set; }
        public string Pin { get; private set; }
        public SavingsAccount SavingsAccount { get; private set; }
        public CurrentAccount CurrentAccount { get; private set; }

        public Customer(string firstName, string lastName, string accountNumber, string pin)
        {
            FirstName = firstName;
            LastName = lastName;
            AccountNumber = accountNumber;
            Pin = pin;
            SavingsAccount = new SavingsAccount();
            CurrentAccount = new CurrentAccount();
        }

        // Login Function to validate the account number and pin.
        public bool Login(string accountNumber, string pin)
        {
            return this.AccountNumber == accountNumber && this.Pin == pin;
        }

        //Function to view transaction history for a specified account type (savings or current).
        public void ViewTransactionHistory(string accountType)
        {
            Console.WriteLine($"Transaction History for {accountType} Account ({this.AccountNumber}):");

            if (accountType.ToLower() == "savings")
            {
                SavingsAccount savingAccount = new();
                foreach (var transaction in savingAccount.Transactions)
                {
                    Console.WriteLine($"{transaction.Date.ToString("dd-MM-yyyy")} {transaction.Type} {transaction.Amount} {transaction.Balance}");
                }
            }
            else if (accountType.ToLower() == "current")
            {
                CurrentAccount currentAccount = new();
                foreach (var transaction in currentAccount.Transactions)
                {
                    Console.WriteLine($"{transaction.Date.ToString("dd-MM-yyyy")} {transaction.Type} {transaction.Amount} {transaction.Balance}");
                }
            }
            else
            {
                Console.WriteLine($"Invalid Account Type");
            }
                        
        }

        //Funtion to deposit a specified amount into a selected account (savings or current).
        public void Deposit(string accountType, double amount)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Deposit amount must be greater than zero.");
                return;
            }

            if (accountType.ToLower() == "savings")
            {
                SavingsAccount savingAccount = new();
                savingAccount.Deposit(amount);
                Console.WriteLine($"Deposited {amount} into {accountType} account. New balance: {savingAccount.Balance}");
            }
            else if (accountType.ToLower() == "current")
            {
                CurrentAccount currentAccount = new();
                currentAccount.Deposit(amount);
                Console.WriteLine($"Deposited {amount} into {accountType} account. New balance: {currentAccount.Balance}");
            }
            else
            {
                Console.WriteLine($"Invalid Account Type");
            }
        }

        //Function to withdraw a specified amount from a selected account (savings or current).
        public void Withdraw(string accountType, double amount)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Withdrawal amount must be greater than zero.");
                return;
            }

            if (accountType.ToLower() == "savings")
            {
                SavingsAccount savingAccount = new();
                if (savingAccount.Balance >= amount)
                {
                    savingAccount.Withdraw(amount);
                    Console.WriteLine($"Withdrew {amount} from {accountType} account. New balance: {savingAccount.Balance}");
                }
                else
                {
                    Console.WriteLine("Insufficient funds.");
                }
            }
            else if (accountType.ToLower() == "current")
            {
                CurrentAccount currentAccount = new();
                if (currentAccount.Balance >= amount)
                {
                    currentAccount.Withdraw(amount);
                    Console.WriteLine($"Withdrew {amount} from {accountType} account. New balance: {currentAccount.Balance}");
                }
                else
                {
                    Console.WriteLine("Insufficient funds.");
                }
            }
            else
            {
                Console.WriteLine($"Invalid Account Type");
            }
           
        }

        // Function to display Account Details
        public string GetAccountDetails()
        {
            return $"Savings: {SavingsAccount.Balance}, Current: {CurrentAccount.Balance}";
        }


    }
}
