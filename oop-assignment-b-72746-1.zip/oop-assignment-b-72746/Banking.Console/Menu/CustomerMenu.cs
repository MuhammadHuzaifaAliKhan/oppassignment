﻿using Banking.Domain.Classes;
using System;
using System.Linq;

public class CustomerMenu
{
    // Customer Login
    public void CustomerLogin(BankEmployee bankEmployee)
    {
        try
        {
            Console.WriteLine("\nCustomer Login");

            Console.WriteLine("\nEnter First Name:");
            string firstName = Console.ReadLine();

            Console.WriteLine("\nEnter Last Name:");
            string lastName = Console.ReadLine();

            Console.WriteLine("\nEnter Account Number:");
            string accountNumber = Console.ReadLine();

            Console.WriteLine("\nEnter PIN:");
            string pin = Console.ReadLine();

            // Attempt to find the customer
            var customer = bankEmployee.GetCustomer(accountNumber, pin);
            if (customer != null)
            {
                Console.WriteLine("\nLogin Successful!");
                // Show Customer Menu
                ShowCustomerMenu(customer, bankEmployee);
            }
            else
            {
                Console.WriteLine("\nInvalid login details. Please try again.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nAn error occurred during login: {ex.Message}");
        }
    }

    // Show Customer Menu
    public void ShowCustomerMenu(Customer customer, BankEmployee bankEmployee)
    {
        string action;
        do
        {
            Console.WriteLine("\nCustomer Menu:");
            Console.WriteLine("1. View Account Details");
            Console.WriteLine("2. View Transaction History");
            Console.WriteLine("3. Deposit Money");
            Console.WriteLine("4. Withdraw Money");
            Console.WriteLine("0. Logout");
            Console.WriteLine("Enter choice:");
            action = Console.ReadLine();

            switch (action)
            {
                case "1":
                    ViewAccountDetails(customer);
                    break;
                case "2":
                    ViewTransactionHistory(customer);
                    break;
                case "3":
                    DepositMoney(customer);
                    break;
                case "4":
                    WithdrawMoney(customer);
                    break;
                case "0":
                    Console.WriteLine("\nLogging out...");
                    break;
                default:
                    Console.WriteLine("\nInvalid option.");
                    break;
            }
        } while (action != "0");
    }

    // View Customer Account Details
    private void ViewAccountDetails(Customer customer)
    {
        try
        {
            Console.WriteLine("\nAccount Details:");
            Console.WriteLine($"Account Number: {customer.AccountNumber}");
            Console.WriteLine($"Savings Account Balance: {customer.SavingsAccount.Balance}");
            Console.WriteLine($"Current Account Balance: {customer.CurrentAccount.Balance}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nAn error occurred while viewing account details: {ex.Message}");
        }
    }

    // View Transaction History
    private void ViewTransactionHistory(Customer customer)
    {
        try
        {
            Console.WriteLine("\nTransaction History (Savings Account):");
            foreach (var transaction in customer.SavingsAccount.Transactions)
            {
                Console.WriteLine("Account Type: Savings, Amount " +  transaction.Type  + " "+ transaction.Amount);
            }

            Console.WriteLine("\nTransaction History (Current Account):");
            foreach (var transaction in customer.CurrentAccount.Transactions)
            {
                Console.WriteLine("Account Type: Current, Amount " + transaction.Type + " " + transaction.Amount);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nAn error occurred while viewing transaction history: {ex.Message}");
        }
    }

    // Deposit Money into an Account
    private void DepositMoney(Customer customer)
    {
        try
        {
            Console.WriteLine("\nEnter Amount to Deposit:");
            double amount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\nWhich account would you like to deposit into? (savings/current)");
            string accountType = Console.ReadLine();

            if (accountType.ToLower() == "savings")
            {
                customer.SavingsAccount.Deposit(amount);
                Console.WriteLine($"\nDeposited {amount} into Savings Account. New balance: {customer.SavingsAccount.Balance}");
            }
            else if (accountType.ToLower() == "current")
            {
                customer.CurrentAccount.Deposit(amount);
                Console.WriteLine($"\nDeposited {amount} into Current Account. New balance: {customer.CurrentAccount.Balance}");
            }
            else
            {
                Console.WriteLine("\nInvalid account type.");
            }

            var fileManager = new FileManager();
            fileManager.SaveTransactions(customer.AccountNumber, accountType, "Deposit " + amount);
        }
        catch (FormatException ex)
        {
            Console.WriteLine("\nInvalid amount format. Please enter a valid number.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nAn error occurred while depositing money: {ex.Message}");
        }
    }

    // Withdraw Money from an Account
    private void WithdrawMoney(Customer customer)
    {
        try
        {
            Console.WriteLine("\nEnter Amount to Withdraw:");
            double amount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\nWhich account would you like to withdraw from? (savings/current)");
            string accountType = Console.ReadLine();

            if (accountType.ToLower() == "savings")
            {
                customer.SavingsAccount.Withdraw(amount);
                Console.WriteLine($"\nWithdrew {amount} from Savings Account. New balance: {customer.SavingsAccount.Balance}");
            }
            else if (accountType.ToLower() == "current")
            {
                customer.CurrentAccount.Withdraw(amount);
                Console.WriteLine($"\nWithdrew {amount} from Current Account. New balance: {customer.CurrentAccount.Balance}");
            }
            else
            {
                Console.WriteLine("\nInvalid account type.");
            }

            var fileManager = new FileManager();
            fileManager.SaveTransactions(customer.AccountNumber, accountType, "Withdraw " + amount);
        }
        catch (FormatException ex)
        {
            Console.WriteLine("\nInvalid amount format. Please enter a valid number.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nAn error occurred while withdrawing money: {ex.Message}");
        }
    }
}
