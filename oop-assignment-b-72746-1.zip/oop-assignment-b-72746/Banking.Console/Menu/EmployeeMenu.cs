﻿using Banking.Domain.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class EmployeeMenu
{

    // Bank Employee Menu
    public void ShowEmployeeMenu(BankEmployee bankEmployee)
    {
        string action;
        do
        {
            Console.WriteLine("\nEmployee Menu:");
            Console.WriteLine("1. Create Customer");
            Console.WriteLine("2. Delete Customer");
            Console.WriteLine("3. List Customers");
            Console.WriteLine("4. Create Transaction");
            Console.WriteLine("0. Exit");
            Console.WriteLine("\nEnter choice:");
            action = Console.ReadLine();

            switch (action)
            {
                case "1":
                    CreateCustomer(bankEmployee);
                    break;
                case "2":
                    DeleteCustomer(bankEmployee);
                    break;
                case "3":
                   bankEmployee.ListCustomers();
                    break;
                case "4":
                    CreateTransaction(bankEmployee);
                    break;
                case "0":
                    break;
                default:
                    Console.WriteLine("\nInvalid option.");
                    break;
            }
        } while (action != "0");
    }

    // Create Customer (Employee Menu)
    private void CreateCustomer(BankEmployee bankEmployee)
    {
        Console.WriteLine("\nEnter First Name:");
        string firstName = Console.ReadLine();

        Console.WriteLine("\nEnter Last Name:");
        string lastName = Console.ReadLine();

        string email = string.Empty;  // Initialize the email variable to an empty string
        bool validEmail = false;

        // Email format validation
        while (!validEmail)
        {
            Console.WriteLine("\nEnter Email:");
            email = Console.ReadLine();

            // Simple email regex pattern for validation
            validEmail = IsValidEmail(email);

            if (!validEmail)
            {
                Console.WriteLine("Invalid email format. Please enter a valid email address.");
            }
        }

        bankEmployee.CreateCustomer(firstName, lastName, email);
        Console.WriteLine("\nCustomer created.");
    }

    // Method to validate the email format using regex
    private bool IsValidEmail(string email)
    {
        var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        var regex = new System.Text.RegularExpressions.Regex(emailPattern);
        return regex.IsMatch(email);
    }


    // Delete Customer (Employee Menu)
    private void DeleteCustomer(BankEmployee bankEmployee)
    {
        Console.WriteLine("\nEnter Account Number to delete:");
        string accountNumber = Console.ReadLine();
        bankEmployee.DeleteCustomer(accountNumber);
    }

    // Create Transaction (Employee Menu)
    private void CreateTransaction(BankEmployee bankEmployee)
    {
        Console.WriteLine("\nEnter Account Number:");
        string accountNumber = Console.ReadLine();
        Console.WriteLine("\nEnter Account Type (savings/current):");
        string accountType = Console.ReadLine();
        Console.WriteLine("\nEnter Transaction Type (deposit/withdraw):");
        string transactionType = Console.ReadLine();
        Console.WriteLine("\nEnter Amount:");
        double amount = Convert.ToDouble(Console.ReadLine());
        bankEmployee.CreateTransaction(accountNumber, accountType, amount, transactionType);
    }
}

