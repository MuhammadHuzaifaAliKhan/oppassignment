﻿using Banking.Tests;
using Banking.Tests.TestCases;
using System;

public class Driver
{
    static void Main(string[] args)
    {
        Console.WriteLine("Running all tests...");

        // Creating an instance of the test class
        var customerTests = new CustomerTests();
        var savingsAccountTests = new SavingsAccountTests();
        var currentAccountTests = new CurrentAccountTests();
        var bankEmployeeTests = new BankEmployeeTests();
        var transactionTests = new TransactionTests();
        var accountFactoryTests = new AccountFactoryTests();
        var fileManagerTests = new FileManagerTests();


        //Calling Customer Test cases
        Console.WriteLine("\n----Calling Customer Test cases----");

        customerTests.DepositMoney_ValidAmount_AmountDeposited();
        customerTests.WithdrawMoney_ValidAmount_AmountWithdrawn();
        customerTests.WithdrawMoney_InsufficientFunds_ThrowsException();
        customerTests.ViewAccountDetails_ReturnsCorrectDetails();

        Console.WriteLine("\n----Customer Test cases executed Successfully----");


        //Calling Saving Account Test cases
        Console.WriteLine("\n----Calling Saving Account Test cases----");

        savingsAccountTests.Deposit_ValidAmount_IncreasesBalance();
        savingsAccountTests.Withdraw_ValidAmount_DecreasesBalance();
        savingsAccountTests.Withdraw_InsufficientFunds_ThrowsException();

        Console.WriteLine("\n----Calling Saving Account Test cases executed Successfully----");


        //Calling Current Account Test cases
        Console.WriteLine("\n----Calling Current Account Test cases----");

        currentAccountTests.Deposit_ValidAmount_IncreasesBalance();
        currentAccountTests.Withdraw_ValidAmount_DecreasesBalance();
        currentAccountTests.Withdraw_InsufficientFunds_ThrowsException();

        Console.WriteLine("\n----Calling Current Account Test cases executed Successfully----");


        //Calling Bank Employee Test cases
        Console.WriteLine("\n----Calling Bank Employee Test cases----");

        bankEmployeeTests.CreateCustomer_ValidData_CustomerCreated();
        bankEmployeeTests.DeleteCustomer_CustomerExists_DeletedSuccessfully();
        bankEmployeeTests.ListCustomers_CustomersExist_ListsCustomers();
        bankEmployeeTests.CreateTransaction_ValidTransaction_TransactionCreated();

        Console.WriteLine("\n----Calling Bank Employee Test cases executed Successfully----");


        //Calling Transactions Test cases
        Console.WriteLine("\n----Calling Transactions Test cases----");

        transactionTests.CreateTransaction_CreatesTransactionWithCorrectDetails();
        transactionTests.DateFormatter_ReturnsCorrectFormattedDate();
        transactionTests.DateFormatter_FormatsDateCorrectly();
        transactionTests.TransactionCreation_CreatesTransactionAtCurrentTime();
        transactionTests.CreateTransaction_ValidTransaction_CorrectDateTimeAssigned();
        transactionTests.CreateTransaction_TransactionDetailsCorrect();

        Console.WriteLine("\n----Calling Transactions Test cases executed Successfully----");


        //Calling Account Factory test cases
        Console.WriteLine("\n----Calling Account Factory test cases----");

        accountFactoryTests.CreateSavingsAccount_CreatesNewSavingsAccountInstance();
        accountFactoryTests.CreateCurrentAccount_CreatesNewCurrentAccountInstance();
        accountFactoryTests.CreateSavingsAccount_ReturnsDifferentInstances();
        accountFactoryTests.CreateCurrentAccount_ReturnsDifferentInstances();

        Console.WriteLine("\n----Calling Account Factory test cases executed Successfully----");


        //Calling File Manager test cases
        Console.WriteLine("\n----Calling File Manager test cases----");

        fileManagerTests.CreateCustomerFile_CreatesFileIfNotExist();
        fileManagerTests.CreateCustomerFile_DoesNotOverwriteExistingFile();
        fileManagerTests.SaveTransactions_AppendsTransactionDetailsToFile();
        fileManagerTests.SaveTransactions_CreatesNewFileIfNotExist();
        fileManagerTests.SaveTransactions_AppendsToExistingFile();

        Console.WriteLine("\n----Calling File Manager test cases executed Successfully----");

    }
}
