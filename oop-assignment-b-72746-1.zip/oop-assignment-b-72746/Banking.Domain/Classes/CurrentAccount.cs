﻿using Banking.Domain.Abstract_Classes;

// CurrentAccount class extends the Account abstract class
public class CurrentAccount : Account
{
    public double Balance { get; private set; }

    public CurrentAccount()
    {
        Balance = 0;  // Ensure the balance starts at 0.
    }
    // Override the Deposit method to handle deposits for the CurrentAccount.
    public override void Deposit(double amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Deposit amount must be positive.");
            return;
        }

        Balance += amount;
        AddTransaction("Deposit", amount);
    }

    // Override the Withdraw method to handle withdrawals for the CurrentAccount.
    public override void Withdraw(double amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Withdrawal amount must be positive.");
            return;
        }

        if (Balance >= amount)
        {
            Balance -= amount;
            AddTransaction("Withdrawal", amount);
        }
        else
        {
            throw new InvalidOperationException("Insufficient funds.");
        }
    }
    // Method to reset the balance to zero(could be useful for testing)
    public void ResetBalance()
    {
        Balance = 0;
    }
}