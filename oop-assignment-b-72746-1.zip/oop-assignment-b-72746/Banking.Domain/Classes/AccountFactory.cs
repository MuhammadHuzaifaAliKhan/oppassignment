﻿

using Banking.Domain.Interfaces;

namespace Banking.Domain.Classes
{
    // AccountFactory class implements the IAccountFactory interface
    public class AccountFactory : IAccountFactory
    {
        // Function to creates and returns a new Saving Account instance with default values.
        public SavingsAccount CreateSavingsAccount()
        {
            return new SavingsAccount(); 
        }

        // Function to creates and returns a new Current Account instance with default values.
        public CurrentAccount CreateCurrentAccount()
        {
            return new CurrentAccount();
        }
    }
}
