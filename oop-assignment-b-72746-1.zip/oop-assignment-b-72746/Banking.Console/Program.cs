﻿using Banking.Domain.Classes;

public class Program
{
    public static void Main()
    {
        BankEmployee bankEmployee = new BankEmployee();
        CustomerMenu customerMenu = new CustomerMenu();
        EmployeeMenu employeeMenu = new EmployeeMenu();

        // Main loop for login menu
        bool exitProgram = false;
        while (!exitProgram)
        {
            Console.WriteLine("\nWelcome to the Banking System");

            try
            {
                Console.WriteLine("\nAre you a [1] Bank Employee or [2] Customer? Enter 0 to Exit.");
                string userType = Console.ReadLine();

                switch (userType)
                {
                    case "1":
                        Console.WriteLine("\nPlease enter Employee PIN:");
                        string pin = Console.ReadLine();
                        if (pin == "A1234")
                        {
                            employeeMenu.ShowEmployeeMenu(bankEmployee);
                        }
                        else
                        {
                            Console.WriteLine("\nInvalid PIN.");
                        }
                        break;

                    case "2":
                        customerMenu.CustomerLogin(bankEmployee);
                        break;

                    case "0":
                        exitProgram = true;
                        Console.WriteLine("\nExiting the system...");
                        break;

                    default:
                        Console.WriteLine("\nInvalid choice.");
                        break;
                }
            }
            catch (FormatException ex)
            {
                // Handle invalid input format (e.g., if user enters a non-numeric value)
                Console.WriteLine("\nError: Invalid input format. Please enter a valid number.");
                Console.WriteLine($"Details: {ex.Message}");
            }
            catch (ArgumentException ex)
            {
                // Handle argument-related exceptions (e.g., invalid argument passed to a method)
                Console.WriteLine("\nError: Invalid argument. Please check your input.");
                Console.WriteLine($"Details: {ex.Message}");
            }
            catch (Exception ex)
            {
                // Catch any other unexpected exceptions
                Console.WriteLine("\nAn unexpected error occurred.");
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                // This block will always execute, whether there was an exception or not
                Console.WriteLine("\nThank you for using the Banking System!");
            }
        }
    }

}
