﻿using Banking.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Banking.Domain.Classes
{
    // Transaction implements ITransaction for creating and handling transactions
    public class Transaction : ITransaction
    {
        public DateTime Date { get; set; }
        public string Type { get; set; }
        public double Amount { get; set; }
        public double Balance { get; set; }

        public Transaction(DateTime date, string type, double amount, double balance)
        {
            Date = date;
            Type = type;
            Amount = amount;
            Balance = balance;
        }

        // Function to return a formatted string for the transaction details
        public string DateFormatter()
        {
            return $"{Date:dd-MM-yyyy}\t{Type}\t{Amount}\t{Balance}";
        }

        // Static Function to create a new transaction instance
        public static Transaction CreateTransaction(string type, double amount, double balance)
        {
            return new Transaction(DateTime.Now, type, amount, balance);
        }
    }
}
