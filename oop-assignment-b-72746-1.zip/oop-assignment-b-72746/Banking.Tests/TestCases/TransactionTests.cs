﻿using Xunit;
using Banking.Domain.Classes;
using System;

namespace Banking.Tests.TestCases
{
    public class TransactionTests
    {
        [Fact]
        public void CreateTransaction_CreatesTransactionWithCorrectDetails()
        {
            // Arrange
            string type = "Deposit";
            double amount = 1000;
            double balance = 5000;

            // Act
            var transaction = Transaction.CreateTransaction(type, amount, balance);

            // Assert
            Assert.Equal(type, transaction.Type);
            Assert.Equal(amount, transaction.Amount);
            Assert.Equal(balance, transaction.Balance);
            Assert.True(transaction.Date <= DateTime.Now);  // Check if the date is current or past
        }

        [Fact]
        public void DateFormatter_ReturnsCorrectFormattedDate()
        {
            // Arrange
            var transaction = new Transaction(DateTime.Now, "Deposit", 1000, 5000);

            // Act
            var formattedDate = transaction.DateFormatter();

            // Assert
            Assert.Contains(transaction.Date.ToString("dd-MM-yyyy"), formattedDate);
            Assert.Contains("Deposit", formattedDate);
            Assert.Contains("1000", formattedDate);
            Assert.Contains("5000", formattedDate);
        }

        [Fact]
        public void DateFormatter_FormatsDateCorrectly()
        {
            // Arrange
            var transaction = new Transaction(new DateTime(2024, 12, 25), "Withdrawal", 500, 4500);

            // Act
            var formattedDate = transaction.DateFormatter();

            // Assert
            Assert.Equal("25-12-2024\tWithdrawal\t500\t4500", formattedDate);
        }

        [Fact]
        public void TransactionCreation_CreatesTransactionAtCurrentTime()
        {
            // Arrange
            string type = "Deposit";
            double amount = 2000;
            double balance = 3000;

            // Act
            var transaction = Transaction.CreateTransaction(type, amount, balance);
            var currentTime = DateTime.Now;

            // Assert
            Assert.True(transaction.Date <= currentTime); // Ensures the transaction was created at the current time
        }

        [Fact]
        public void CreateTransaction_ValidTransaction_CorrectDateTimeAssigned()
        {
            // Arrange
            string type = "Deposit";
            double amount = 1000;
            double balance = 5000;

            // Act
            var transaction = Transaction.CreateTransaction(type, amount, balance);

            // Assert
            Assert.Equal(type, transaction.Type);
            Assert.Equal(amount, transaction.Amount);
            Assert.Equal(balance, transaction.Balance);
            Assert.True(transaction.Date > DateTime.MinValue); // Ensure the transaction has a valid date
        }

        [Fact]
        public void CreateTransaction_TransactionDetailsCorrect()
        {
            // Arrange
            string type = "Withdraw";
            double amount = 500;
            double balance = 4500;

            // Act
            var transaction = Transaction.CreateTransaction(type, amount, balance);

            // Assert
            Assert.Equal("Withdraw", transaction.Type);
            Assert.Equal(500, transaction.Amount);
            Assert.Equal(4500, transaction.Balance);
            Assert.True(transaction.Date <= DateTime.Now); // Check that the transaction date is set correctly
        }
    }
}
