﻿using Xunit;
using Banking.Domain.Classes;

namespace Banking.Tests.TestCases
{
    public class CurrentAccountTests
    {
        private CurrentAccount _currentAccount;

        public CurrentAccountTests()
        {
            _currentAccount = new CurrentAccount();
        }

        [Fact]
        public void Deposit_ValidAmount_IncreasesBalance()
        {
            _currentAccount.ResetBalance();

            // Act
            _currentAccount.Deposit(500);

            // Assert
            Assert.Equal(500, _currentAccount.Balance);
        }

        [Fact]
        public void Withdraw_ValidAmount_DecreasesBalance()
        {
            _currentAccount.ResetBalance();

            // Arrange
            _currentAccount.Deposit(500);

            // Act
            _currentAccount.Withdraw(200);

            // Assert
            Assert.Equal(300, _currentAccount.Balance);
        }

        [Fact]
        public void Withdraw_InsufficientFunds_ThrowsException()
        {
            _currentAccount.ResetBalance();

            // Arrange
            _currentAccount.Deposit(200);

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() => _currentAccount.Withdraw(300));
            Assert.Equal("Insufficient funds.", exception.Message);
        }
    }
}
