﻿using Banking.Domain.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Interfaces
{
    public interface IBankEmployee
    { 
        //Functions Signature
        void CreateCustomer(string firstName, string lastName, string email);
        void DeleteCustomer(string accountNumber);
        List<string> ListCustomers();
        Customer GetCustomer(string accountNumber, string pin);
        void CreateTransaction(string accountNumber, string accountType, double amount, string transactionType);
    }
}
