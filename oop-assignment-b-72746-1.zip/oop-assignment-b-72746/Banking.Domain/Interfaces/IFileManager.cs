﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Domain.Interfaces
{
    public interface IFileManager
    {
        //Functions Signature
        void CreateCustomerFile(string filename);
        void AddDataInCustomerFile(List<string> customerDetails);
        void SaveTransactions(string accountNumber, string accountType, string transactionDetails);
    }
}
